#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    // Настройка продуктов
    setupProducts();

    // Создаем виджеты
    productsList = new QListWidget(this);
    billList = new QListWidget(this);
    quantitySpin = new QSpinBox(this);
    quantitySpin->setMinimum(1);
    quantitySpin->setMaximum(99);
    quantitySpin->setValue(1);

    // Заполняем список продуктов
    for (const auto &product : products) {
        productsList->addItem(QString("%1 - %2 руб.").arg(product.name).arg(product.price));
    }

    // Кнопки
    addButton = new QPushButton("Добавить в чек", this);
    clearButton = new QPushButton("Очистить чек", this);
    payButton = new QPushButton("Оплатить", this);

    // Разметка
    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);

    mainLayout->addWidget(new QLabel("Продукты:"));
    mainLayout->addWidget(productsList);

    QHBoxLayout *quantityLayout = new QHBoxLayout();
    quantityLayout->addWidget(new QLabel("Количество:"));
    quantityLayout->addWidget(quantitySpin);
    quantityLayout->addStretch();
    mainLayout->addLayout(quantityLayout);

    mainLayout->addWidget(addButton);
    mainLayout->addWidget(new QLabel("Чек:"));
    mainLayout->addWidget(billList);

    QHBoxLayout *buttonLayout = new QHBoxLayout();
    buttonLayout->addWidget(clearButton);
    buttonLayout->addWidget(payButton);
    mainLayout->addLayout(buttonLayout);

    setCentralWidget(centralWidget);

    // Подключаем кнопки
    connect(addButton, &QPushButton::clicked, this, &MainWindow::addToBill);
    connect(clearButton, &QPushButton::clicked, this, &MainWindow::clearBill);
    connect(payButton, &QPushButton::clicked, this, &MainWindow::pay);

    resize(400, 500);
    setWindowTitle("Мини-касса");
}

void MainWindow::setupProducts()
{
    products = {
        {"Хлеб", 50},
        {"Молоко", 80},
        {"Яйца", 120},
        {"Сахар", 60},
        {"Масло", 150}
    };
}

void MainWindow::addToBill()
{
    if (productsList->currentRow() >= 0) {
        const auto &product = products[productsList->currentRow()];
        int quantity = quantitySpin->value();

        // Добавляем/обновляем количество в чеке
        billItems[product.name] = billItems.value(product.name, 0) + quantity;

        // Пересчитываем сумму
        total += product.price * quantity;

        updateBill();
    }
}

void MainWindow::updateBill()
{
    billList->clear();
    for (auto it = billItems.begin(); it != billItems.end(); ++it) {
        QString name = it.key();
        int quantity = it.value();
        double price = 0;

        // Находим цену продукта
        for (const auto &product : products) {
            if (product.name == name) {
                price = product.price;
                break;
            }
        }

        billList->addItem(QString("%1 x%2 - %3 руб.")
                              .arg(name)
                              .arg(quantity)
                              .arg(price * quantity));
    }
}

void MainWindow::clearBill()
{
    billList->clear();
    billItems.clear();
    total = 0;
}

void MainWindow::pay()
{
    if (billItems.isEmpty()) {
        return;
    }

    QMessageBox::information(this, "Оплата", QString("Оплачено %1 руб.").arg(total));
    clearBill();
}

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QListWidget>
#include <QSpinBox>
#include <QPushButton>
#include <QMap>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);

private slots:
    void addToBill();
    void clearBill();
    void pay();

private:
    QListWidget *productsList;
    QListWidget *billList;
    QSpinBox *quantitySpin;
    QPushButton *addButton;
    QPushButton *clearButton;
    QPushButton *payButton;

    struct Product {
        QString name;
        double price;
    };

    QList<Product> products;
    QMap<QString, int> billItems; // name -> quantity
    double total = 0;

    void setupProducts();
    void updateBill();
};

#endif

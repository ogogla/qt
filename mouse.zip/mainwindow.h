#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QLabel>
#include <QPushButton>
#include <QRandomGenerator>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void startGame();
    void updateGame();
    void moveCircle();
    void updateTimer();

private:
    void setupUI();
    void mousePressEvent(QMouseEvent *event) override;

    QLabel *scoreLabel;
    QLabel *timeLabel;
    QPushButton *startButton;
    QPushButton *circleButton;

    QTimer *Timer;

    int score;
    int timeLeft;
};

#endif // MAINWINDOW_H

#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QWidget>
#include <QMouseEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), score(0), timeLeft(60)
{
    setupUI();

    Timer = new QTimer(this);

    connect(Timer, &QTimer::timeout, this, &MainWindow::updateTimer);
    connect(startButton, &QPushButton::clicked, this, &MainWindow::startGame);
}

MainWindow::~MainWindow()
{
}

void MainWindow::setupUI()
{
    QWidget *centralWidget = new QWidget(this);

    scoreLabel = new QLabel("Score: 0", this);
    timeLabel = new QLabel("Time: 60", this);
    scoreLabel->move(0,0);
    timeLabel->move(350, 0);

    startButton = new QPushButton("Start Game", this);
    startButton->move(150, 350);

    circleButton = new QPushButton(this);
    circleButton->setFixedSize(30, 30);
    circleButton->setStyleSheet("QPushButton {"
                                "background-color: red;"
                                "border-radius: 25px;"
                                "}");
    circleButton->setVisible(false);
    connect(circleButton, &QPushButton::clicked, [this]() {
        score++;
        scoreLabel->setText("Score: " + QString::number(score));
    });


    setCentralWidget(centralWidget);
    resize(400, 400);
}

void MainWindow::startGame()
{
    score = 0;
    timeLeft = 60;
    scoreLabel->setText("Score: 0");
    timeLabel->setText("Time: 60");

    startButton->setEnabled(false);
    circleButton->setVisible(true);
    moveCircle();

    Timer->start(1000);
}

void MainWindow::updateGame()
{
    if (timeLeft <= 0) {
        Timer->stop();
        circleButton->setVisible(false);
        startButton->setEnabled(true);
    }
}

void MainWindow::moveCircle()
{
    QRandomGenerator *generator = QRandomGenerator::global();

    int maxX = width() - circleButton->width();
    int maxY = height() - circleButton->height();

    int newX = generator->bounded(maxX);
    int newY = generator->bounded(maxY);

    circleButton->move(newX, newY);
}

void MainWindow::updateTimer()
{
    timeLeft--;
    timeLabel->setText("Time: " + QString::number(timeLeft));

    if (timeLeft <= 0) {
        updateGame();
    }
    moveCircle();
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (circleButton->isVisible() && circleButton->geometry().contains(event->pos())) {
        score++;
        scoreLabel->setText("Score: " + QString::number(score));
    }
    QMainWindow::mousePressEvent(event);
}

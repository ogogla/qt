#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QKeyEvent>
#include <QTimer>
#include <QPainter>
#include <QRect>
#include <QVector>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void paintEvent(QPaintEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;
    void keyReleaseEvent(QKeyEvent *event) override;

private slots:
    void updateGame();

private:
    void initGame();
    void checkCollisions();
    void drawGame(QPainter &painter);
    void gameOver();
    void checkLevelComplete();

    QRect paddle;
    QRect ball;
    QVector<QRect> bricks;

    int paddleSpeed;
    int ballSpeedX;
    int ballSpeedY;
    bool leftKeyPressed;
    bool rightKeyPressed;
    bool gameRunning;
    int score;
    int lives;

    QTimer *timer;
};
#endif // MAINWINDOW_H

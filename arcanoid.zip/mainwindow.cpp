#include "mainwindow.h"
#include <QPainter>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setFixedSize(800, 600);
    setWindowTitle("Arkanoid");

    leftKeyPressed = false;
    rightKeyPressed = false;
    gameRunning = false;
    score = 0;
    lives = 3;

    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::updateGame);

    initGame();
    timer->start(16);
}

MainWindow::~MainWindow()
{
    delete timer;
}

void MainWindow::initGame()
{
    paddle = QRect(width()/2 - 50, height() - 30, 100, 15);
    paddleSpeed = 8;

    ball = QRect(width()/2 - 7, height()/2 - 7, 14, 14);
    ballSpeedX = 4;
    ballSpeedY = -4;

    bricks.clear();
    const int brickWidth = 75;
    const int brickHeight = 20;
    const int brickRows = 5;
    const int brickCols = 10;

    for (int i = 0; i < brickRows; ++i) {
        for (int j = 0; j < brickCols; ++j) {
            int x = j * (brickWidth + 5) + 15;
            int y = i * (brickHeight + 5) + 50;
            bricks.append(QRect(x, y, brickWidth, brickHeight));
        }
    }

    gameRunning = true;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    drawGame(painter);
}

void MainWindow::drawGame(QPainter &painter)
{
    painter.fillRect(rect(), Qt::black);

    painter.setBrush(Qt::white);
    painter.drawRect(paddle);

    painter.setBrush(Qt::red);
    painter.drawEllipse(ball);

    painter.setBrush(Qt::green);
    for (const QRect &brick : bricks) {
        painter.drawRect(brick);
    }

    painter.setPen(Qt::white);
    painter.drawText(20, 20, QString("Score: %1").arg(score));
    painter.drawText(width() - 100, 20, QString("Lives: %1").arg(lives));
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    switch (event->key()) {
    case Qt::Key_Left:
        leftKeyPressed = true;
        break;
    case Qt::Key_Right:
        rightKeyPressed = true;
        break;
    case Qt::Key_Space:
        if (!gameRunning) {
            initGame();
        }
        break;
    default:
        QMainWindow::keyPressEvent(event);
    }
}

void MainWindow::keyReleaseEvent(QKeyEvent *event)
{
    switch (event->key()) {
    case Qt::Key_Left:
        leftKeyPressed = false;
        break;
    case Qt::Key_Right:
        rightKeyPressed = false;
        break;
    default:
        QMainWindow::keyReleaseEvent(event);
    }
}

void MainWindow::updateGame()
{
    if (!gameRunning) return;

    if (leftKeyPressed && paddle.left() > 0) {
        paddle.moveLeft(paddle.left() - paddleSpeed);
    }
    if (rightKeyPressed && paddle.right() < width()) {
        paddle.moveLeft(paddle.left() + paddleSpeed);
    }

    ball.moveLeft(ball.left() + ballSpeedX);
    ball.moveTop(ball.top() + ballSpeedY);

    checkCollisions();

    if (ball.bottom() > height()) {
        lives--;
        if (lives <= 0) {
            gameOver();
        } else {
            ball.moveCenter(QPoint(width()/2, height()/2));
            ballSpeedY = -abs(ballSpeedY);
        }
    }

    update();
}

void MainWindow::checkCollisions()
{
    if (ball.left() <= 0 || ball.right() >= width()) {
        ballSpeedX = -ballSpeedX;
    }
    if (ball.top() <= 0) {
        ballSpeedY = -ballSpeedY;
    }

    if (ball.intersects(paddle)) {
        ballSpeedY = -abs(ballSpeedY);
        int hitPos = (ball.center().x() - paddle.left()) / (paddle.width() / 5);
        ballSpeedX = (hitPos - 2) * 2;
    }

    for (int i = 0; i < bricks.size(); ++i) {
        if (ball.intersects(bricks[i])) {
            QRect brick = bricks[i];
            QPoint ballCenter = ball.center();

            if (ballCenter.x() < brick.left() || ballCenter.x() > brick.right()) {
                ballSpeedX = -ballSpeedX;
            } else {
                ballSpeedY = -ballSpeedY;
            }

            bricks.remove(i);
            score += 10;
            checkLevelComplete();
            break;
        }
    }
}

void MainWindow::gameOver()
{
    gameRunning = false;
    QMessageBox::information(this, "Игра окончена", QString("Вы проиграли("));
}

void MainWindow::checkLevelComplete()
{
    if (bricks.isEmpty()) {
        gameRunning = false;
        QMessageBox::information(this, "Игра окончена", "Вы выиграли)");
    }
}

#include "mainwindow.h"
#include <QPainter>
#include <QTime>
#include <QTimer>
#include <cmath>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setFixedSize(400, 400);

    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::updateClock);
    timer->start(1000);

    currentTime = QTime::currentTime();
}

MainWindow::~MainWindow()
{
    delete timer;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    int side = qMin(width(), height());
    painter.translate(width() / 2, height() / 2);
    painter.scale(side / 200.0, side / 200.0);

    drawClockFace(&painter);
    drawHourHand(&painter, currentTime.hour(), currentTime.minute());
    drawMinuteHand(&painter, currentTime.minute(), currentTime.second());
    drawSecondHand(&painter, currentTime.second());
}

void MainWindow::updateClock()
{
    currentTime = QTime::currentTime();
    update();
}

void MainWindow::drawClockFace(QPainter *painter)
{
    painter->save();
    painter->setPen(Qt::black);

    painter->drawEllipse(QPoint(0, 0), 95, 95);
    painter->drawEllipse(QPoint(0, 0), 2, 2);

    QFont font = painter->font();
    font.setPointSize(10);
    painter->setFont(font);

    for (int i = 1; i <= 12; ++i) {
        painter->save();
        painter->rotate(30 * i);
        painter->translate(0, -80);
        painter->drawText(QRect(-10, -10, 20, 20), Qt::AlignCenter, QString::number(i));
        painter->restore();
    }

    painter->restore();
}

void MainWindow::drawHourHand(QPainter *painter, float hour, float minute)
{
    painter->save();
    QPen pen(Qt::black, 4);
    painter->setPen(pen);

    hour = hour + minute / 60.0;
    painter->rotate(30.0 * hour);
    painter->drawLine(QPoint(0, 0), QPoint(0, -40));
    painter->restore();
}

void MainWindow::drawMinuteHand(QPainter *painter, float minute, float second)
{
    painter->save();
    QPen pen(Qt::black, 2);
    painter->setPen(pen);

    minute = minute + second / 60.0;
    painter->rotate(6.0 * minute);
    painter->drawLine(QPoint(0, 0), QPoint(0, -60));
    painter->restore();
}

void MainWindow::drawSecondHand(QPainter *painter, float second)
{
    painter->save();
    QPen pen(Qt::red, 1);
    painter->setPen(pen);

    painter->rotate(6.0 * second);
    painter->drawLine(QPoint(0, 0), QPoint(0, -70));
    painter->restore();
}

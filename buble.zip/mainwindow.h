#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QPainter>
#include <QVector>
#include <QRandomGenerator>

class Ball {
public:
    Ball(int windowWidth);
    void update();
    void draw(QPainter &painter);
    void reset(int windowWidth);
    double x, y;
    double speed;
    double radius;
    double opacity;
    QColor color;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void paintEvent(QPaintEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

private slots:
    void updateBalls();

private:
    QTimer *timer;
    QVector<Ball> balls;
    int BALL_COUNT = 1;
};

#endif // MAINWINDOW_H

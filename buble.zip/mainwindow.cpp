#include "mainwindow.h"
#include <QPainter>
#include <QRandomGenerator>

Ball::Ball(int windowWidth) {
    reset(windowWidth);
}

void Ball::update() {
    y -= speed;
}

void Ball::draw(QPainter &painter) {
    QColor ballColor = color;
    ballColor.setAlphaF(opacity);
    painter.setBrush(ballColor);
    painter.setPen(Qt::NoPen);
    painter.drawEllipse(QPointF(x, y), radius, radius);
}

void Ball::reset(int windowWidth) {
    x = QRandomGenerator::global()->bounded(windowWidth);
    y = windowWidth;
    speed = QRandomGenerator::global()->bounded(4.0) + 1.0;
    radius = QRandomGenerator::global()->bounded(20.0) + 10.0;
    opacity = QRandomGenerator::global()->bounded(0.7) + 0.3;
    color = QColor::fromHsv(QRandomGenerator::global()->bounded(360), 255, 255);
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setFixedSize(800, 600);

    for (int i = 0; i < BALL_COUNT; ++i) {
        balls.append(Ball(width()));
    }

    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::updateBalls);
    timer->start(16);
}

MainWindow::~MainWindow() {}

void MainWindow::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);

    QPainter painter(this);

    for (Ball &ball : balls) {
        ball.draw(painter);
    }
}

void MainWindow::resizeEvent(QResizeEvent *event) {
    QMainWindow::resizeEvent(event);
    balls.clear();
    for (int i = 0; i < BALL_COUNT; ++i) {
        balls.append(Ball(width()));
    }
}

void MainWindow::updateBalls() {
    for (Ball &ball : balls) {
        ball.update();

        if (ball.y + ball.radius < 0) {
            ball.reset(width());
        }
    }
    update();
}
